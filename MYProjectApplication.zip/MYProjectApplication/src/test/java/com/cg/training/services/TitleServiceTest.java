//package com.cg.training.services;
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//import java.time.LocalDate;
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.cg.training.entities.Titles;
//import com.cg.training.exceptions.TitlesNotFoundException;
//
//@SpringBootTest
//public class TitleServiceTest {
//
//    @Mock
//    private TitleService titleService;
//
//    @BeforeEach
//    public void setup() {
//        MockitoAnnotations.initMocks(this);
//    }
//
//    
//    private Titles createTitles(int empNo, String title, LocalDate fromDate, LocalDate toDate) {
//        Titles titles = new Titles();
//        titles.setEmpNo(empNo);
//        titles.setTitle(title);
//        titles.setFromDate(fromDate);
//        titles.setToDate(toDate);
//        return titles;
//    }
//
//    @Test
//    public void testGetTitles() {
//        List<Titles> titlesList = new ArrayList<>();
//        titlesList.add(createTitles(10020, "Engineer", LocalDate.parse("1997-12-30"), LocalDate.parse("9999-01-01")));
//        titlesList.add(createTitles(10021, "Technique Leader", LocalDate.parse("1988-02-10"), LocalDate.parse("2002-07-15")));
//        titlesList.add(createTitles(10022, "Engineer", LocalDate.parse("1999-09-03"), LocalDate.parse("9999-01-01")));
//        titlesList.add(createTitles(10023, "Engineer", LocalDate.parse("1999-09-27"), LocalDate.parse("9999-01-01")));
//        titlesList.add(createTitles(10024, "Assistant Engineer", LocalDate.parse("1998-06-14"), LocalDate.parse("9999-01-01")));
//        titlesList.add(createTitles(10025, "Technique Leader", LocalDate.parse("1987-08-17"), LocalDate.parse("1997-10-15")));
//        titlesList.add(createTitles(10026, "Engineer", LocalDate.parse("1995-03-20"), LocalDate.parse("2001-03-19")));
//        titlesList.add(createTitles(10026, "Senior Engineer", LocalDate.parse("2001-03-19"), LocalDate.parse("9999-01-01")));
//        titlesList.add(createTitles(10027, "Engineer", LocalDate.parse("1995-04-02"), LocalDate.parse("2001-04-01")));
//        titlesList.add(createTitles(10027, "Senior Engineer", LocalDate.parse("2001-04-01"), LocalDate.parse("9999-01-01")));
//        titlesList.add(createTitles(10028, "Engineer", LocalDate.parse("1991-10-22"), LocalDate.parse("1998-04-06")));
//        titlesList.add(createTitles(10029, "Engineer", LocalDate.parse("1991-09-18"), LocalDate.parse("2000-09-17")));
//        when(titleService.getTitles()).thenReturn(titlesList);
//
//        List<Titles> result = titleService.getTitles();
//
//        assertEquals(titlesList, result);
//    }
//
//    @Test
//    public void testAddTitle() {
//        Titles titleToAdd = createTitles(10035, "Engineer", LocalDate.parse("2000-01-01"), LocalDate.parse("9999-01-01"));
//
//        when(titleService.addTitle(titleToAdd)).thenReturn(titleToAdd);
//
//        Titles result = titleService.addTitle(titleToAdd);
//
//        assertEquals(titleToAdd, result);
//    }
//
//    @Test
//    public void testGetTitleByEmpNoAndDeptNo() throws TitlesNotFoundException {
//        int empNo = 10021;
//        LocalDate fromDate = LocalDate.parse("1995-01-01");
//        String title = "Technique Leader";
//        List<Titles> titlesList = new ArrayList<>();
//        titlesList.add(createTitles(10021, "Technique Leader", LocalDate.parse("1988-02-10"), LocalDate.parse("2002-07-15")));
//
//        when(titleService.getTitleByEmpNoAndDeptNo(empNo, fromDate, title)).thenReturn(titlesList);
//
//        List<Titles> result = titleService.getTitleByEmpNoAndDeptNo(empNo, fromDate, title);
//
//        assertEquals(titlesList, result);
//    }
//
//    @Test
//    public void testGetTitleByEmpNoAndDeptNo_NotFound() throws TitlesNotFoundException {
//        int empNo = 10034;
//        LocalDate fromDate = LocalDate.parse("2000-01-01");
//        String title = "Staff";
//
//        when(titleService.getTitleByEmpNoAndDeptNo(empNo, fromDate, title)).thenThrow(TitlesNotFoundException.class);
//
//        assertThrows(TitlesNotFoundException.class, () -> titleService.getTitleByEmpNoAndDeptNo(empNo, fromDate, title));
//    }
//
//    @Test
//    public void testGetAllByTitle_NotFound() throws TitlesNotFoundException {
//        String title = "Doctor";
//
//        when(titleService.getAllByTitle(title)).thenThrow(TitlesNotFoundException.class);
//
//        assertThrows(TitlesNotFoundException.class, () -> titleService.getAllByTitle(title));
//    }
//
//
//    @Test
//    public void testGetTitleByTitleAndFromDate_EmpNo() throws TitlesNotFoundException {
//        int empNo = 10026;
//        String title = "Engineer";
//        List<Titles> titlesList = new ArrayList<>();
//        titlesList.add(createTitles(10026, "Engineer", LocalDate.parse("1995-03-20"), LocalDate.parse("2001-03-19")));
//
//        when(titleService.getTitleByTitleAndFromDate(empNo, title)).thenReturn(titlesList);
//
//        List<Titles> result = titleService.getTitleByTitleAndFromDate(empNo, title);
//
//        assertEquals(titlesList, result);
//    }
//
//    @Test
//    public void testGetTitleByTitleAndFromDate_EmpNo_NotFound() throws TitlesNotFoundException {
//        int empNo = 10034;
//        String title = "Doctor";
//
//        when(titleService.getTitleByTitleAndFromDate(empNo, title)).thenThrow(TitlesNotFoundException.class);
//
//        assertThrows(TitlesNotFoundException.class, () -> titleService.getTitleByTitleAndFromDate(empNo, title));
//    }
//
//
//}