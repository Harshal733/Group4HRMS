package com.cg.training.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class EmployeesDto {
	
	 private int empId;

	    @NotNull(message = "Name cannot be null")
	    @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters")
	    private String firstname;
	    
	    @NotNull(message = "Name cannot be null")
	    @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters")
	    private String lasttname;
	    
	   
	    @NotNull(message = "From date cannot be null")
	    private LocalDate fromdate;

	    private LocalDate todate;

	    @NotNull(message = "Department name cannot be null")
	    @Size(min = 2, max = 50, message = "Department name must be between 2 and 50 characters")
	    private String deptname;

		public int getEmpId() {
			return empId;
		}

		public void setEmpId(int empId) {
			this.empId = empId;
		}

		public String getFirstname() {
			return firstname;
		}

		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}

		public String getLasttname() {
			return lasttname;
		}

		public void setLasttname(String lasttname) {
			this.lasttname = lasttname;
		}

		public LocalDate getFromdate() {
			return fromdate;
		}

		public void setFromdate(LocalDate fromdate) {
			this.fromdate = fromdate;
		}

		public LocalDate getTodate() {
			return todate;
		}

		public void setTodate(LocalDate todate) {
			this.todate = todate;
		}

		public String getDeptname() {
			return deptname;
		}

		public void setDeptname(String deptname) {
			this.deptname = deptname;
		}
		
		

		public EmployeesDto() {
			super();
			// TODO Auto-generated constructor stub
		}

		public EmployeesDto(int empId,
				@NotNull(message = "Name cannot be null") @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters") String firstname,
				@NotNull(message = "Name cannot be null") @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters") String lasttname,
				@NotNull(message = "From date cannot be null") LocalDate fromdate, LocalDate todate,
				@NotNull(message = "Department name cannot be null") @Size(min = 2, max = 50, message = "Department name must be between 2 and 50 characters") String deptname) {
			super();
			this.empId = empId;
			this.firstname = firstname;
			this.lasttname = lasttname;
			this.fromdate = fromdate;
			this.todate = todate;
			this.deptname = deptname;
		}

		public String getLastName() {
			// TODO Auto-generated method stub
			return null;
		}
	    
	    

	  
	}


