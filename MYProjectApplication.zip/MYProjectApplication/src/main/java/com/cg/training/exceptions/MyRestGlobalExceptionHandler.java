package com.cg.training.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


import java.time.LocalDateTime;
import java.util.stream.Collectors;


@RestControllerAdvice
public class MyRestGlobalExceptionHandler {

 

	
	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<ApiResponse> handleCustomerNotFoundException(EmployeeNotFoundException ex) {
		return new ResponseEntity<ApiResponse>(new ApiResponse(ex.getMessage(), ex.getMessage()), HttpStatus.NOT_FOUND);
	}


	
	@ExceptionHandler(DepartmentsNotFoundException.class)
	public ResponseEntity<ApiResponse> handleDepatmentNotFoundException(DepartmentsNotFoundException ex) {
		return new ResponseEntity<ApiResponse>(new ApiResponse(ex.getMessage(), ex.getMessage()), HttpStatus.NOT_FOUND);
	}

 

	

 

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorInfo> exceptionHandlerProduct(MethodArgumentNotValidException exception) {
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setErrorCode(HttpStatus.BAD_REQUEST.value());
		String errorMsg = exception.getBindingResult().getAllErrors().stream().map(x -> x.getDefaultMessage())
				.collect(Collectors.joining(","));
		errorInfo.setErrorMessage(errorMsg);
		errorInfo.setTimestamp(LocalDateTime.now());
		return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);
	}

 

}
