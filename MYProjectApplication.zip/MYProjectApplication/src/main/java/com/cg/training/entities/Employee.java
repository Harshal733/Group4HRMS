package com.cg.training.entities;
import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @Column(name = "emp_no", nullable = false)
    private int empNo;

    @Column(name = "birth_date", nullable = false)
    @Past(message = "Birth date must be in the past")
    private LocalDate birthDate;

    @Column(name = "first_name", nullable = false, length = 14)
    @NotBlank(message = "First name is required")
    @Size(max = 14, message = "First name cannot exceed 14 characters")
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 16)
    @NotBlank(message = "Last name is required")
    @Size(max = 16, message = "Last name cannot exceed 16 characters")
    private String lastName;

    @Enumerated(EnumType.STRING)
    @Column(name = "gender", nullable = false)
    private Gender gender;

    @Column(name = "hire_date", nullable = false)
    @PastOrPresent(message = "Hire date must be in the past or present")
    private LocalDate hireDate;

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public LocalDate getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public Employee(int empNo, @Past(message = "Birth date must be in the past") LocalDate birthDate,
			@NotBlank(message = "First name is required") @Size(max = 14, message = "First name cannot exceed 14 characters") String firstName,
			@NotBlank(message = "Last name is required") @Size(max = 16, message = "Last name cannot exceed 16 characters") String lastName,
			Gender gender, @PastOrPresent(message = "Hire date must be in the past or present") LocalDate hireDate) {
		super();
		this.empNo = empNo;
		this.birthDate = birthDate;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.hireDate = hireDate;
	}

	public LocalDate getHireDate() {
		return hireDate;
	}

	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	
    
}

