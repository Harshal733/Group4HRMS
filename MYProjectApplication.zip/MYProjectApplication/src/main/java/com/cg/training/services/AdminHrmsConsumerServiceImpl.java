package com.cg.training.services;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.training.entities.*;
import com.cg.training.dto.AssignDepartmentDto;
import com.cg.training.dto.DepartmentEmployeeDto;
import com.cg.training.dto.EmployeeDto;
import com.cg.training.dto.TitlesDto;
import com.cg.training.entities.Departments;
import com.cg.training.entities.Employee;
import com.cg.training.repository.DepartmentEmployeeRepository;
import com.cg.training.repository.DepartmentManagerRepository;
import com.cg.training.repository.DepartmentsRepository;
import com.cg.training.repository.EmployeeRepository;
import com.cg.training.repository.TitlesRepository;


@Service
public class AdminHrmsConsumerServiceImpl implements AdminHrmsConsumerService {

	
	private final EmployeeRepository employeerepositoryforhrms;
	private final DepartmentEmployeeRepository departmentemployeerepository;
	private final DepartmentsRepository departmentrepository;
	private final EmployeeRepository employeerepository;
	
	@Autowired
	public AdminHrmsConsumerServiceImpl(
			EmployeeRepository employeerepositoryforhrms, 
			DepartmentEmployeeRepository departmentemployeerepository,
			DepartmentManagerRepository departmentmanagerrepository, 
			TitlesRepository titlesrepository,
			DepartmentsRepository departmentrepository,
			EmployeeRepository employeerepository) {
		
		
		this.employeerepositoryforhrms = employeerepositoryforhrms;
		this.departmentemployeerepository = departmentemployeerepository;
		this.departmentrepository = departmentrepository;
		this.employeerepository = employeerepository;
	}
	
	
	 public Collection<EmployeeDto> getEmployeesJoinedLast10Years(int noOfYears) {
	        LocalDate tenYearsAgo = LocalDate.now().minusYears(noOfYears);
	        List<Employee> employees = employeerepository.findByHireDateGreaterThanEqual(tenYearsAgo);

	        return employees.stream()
	                .map(employee -> new EmployeeDto(employee.getEmpNo(), employee.getFirstName(), employee.getLastName(), employee.getHireDate()))
	                .collect(Collectors.toList());
	    }


	 @Override
	 public Collection<EmployeeDto> getEmployeesJoinedinLast10Years(int noOfYears) {
	     LocalDate tenYearsAgo = LocalDate.now().minusYears(noOfYears);
	     List<Employee> employees = employeerepository.findByHireDateGreaterThanEqual(tenYearsAgo);
	     return employees.stream()
	         .map(employee -> {
	             EmployeeDto dto = new EmployeeDto();
	             dto.setEmpNo(employee.getEmpNo());
	             dto.setFirstName(employee.getFirstName());
	             dto.setLastName(employee.getLastName());
	             dto.setHireDate(employee.getHireDate());
	             return dto;
	         })
	         .collect(Collectors.toList());
	 }

	 
	 @Override
	 public void assignDepartment(AssignDepartmentDto assignDepartmentDto) {
	     // Fetch the employee and department IDs from the DTO.
	     Integer employeeId = assignDepartmentDto.getEmployeeId();
	     String departmentId = assignDepartmentDto.getDepartmentId();

	     // Check if the employee and department exist in the database.
	     Employee employee = employeerepository.findById(employeeId).orElse(null);
	     Departments department = departmentrepository.findByDeptNo(departmentId);


	     if (employee != null && department != null) {
	         // Create a new DepartmentEmployee entity to represent the assignment.
	         DepartmentEmployee departmentEmployee = new DepartmentEmployee();
	         departmentEmployee.setEmployee(employee);
	         departmentEmployee.setDepartment(department);
	         departmentEmployee.setFromDate(assignDepartmentDto.getFromDate());
	         departmentEmployee.setToDate(assignDepartmentDto.getEndDate());

	         // Save the DepartmentEmployee entity to the database.
	         departmentemployeerepository.save(departmentEmployee);
	     } else {
	         // Handle the case where the employee or department doesn't exist.
	         // You can throw an exception or return an error message.
	     }
	 }
	 
	  @Override
	    public void addEmployee(EmployeeDto employeeDto) {
	        // Create a new employee entity from the DTO
	        Employee employee = new Employee();
	        employee.setEmpNo(employeeDto.getEmpNo());
	        employee.setBirthDate(employeeDto.getBirthDate());
	        employee.setFirstName(employeeDto.getFirstName());
	        employee.setLastName(employeeDto.getLastName());
	        employee.setGender(employeeDto.getGender());
	        employee.setHireDate(employeeDto.getHireDate());

	        // Save the employee entity to the database
	        employeerepository.save(employee);
	    }


	@Override
	public int countEmployeesJoinedLast10Years(int noOfYears) {
		// TODO Auto-generated method stub
		return 0;
	}

}





	        
	

	 
	



	