package com.cg.training.exceptions;

public class DepartmentsNotFoundException extends Exception{

	String message;

	public DepartmentsNotFoundException(String message) {
		super();
		this.message = message;
	}
	
	public String getMessage() {
		return this.message;
	}
	
}
