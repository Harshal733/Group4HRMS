package com.cg.training.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.training.dto.DepartmentDTO;
import com.cg.training.entities.Departments;
import com.cg.training.exceptions.DepartmentsNotFoundException;
import com.cg.training.repository.DepartmentsRepository;

import jakarta.validation.Valid;
@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentsRepository departmentRepository;
	
	
	
	public List<Departments> getDepartments() {
		return departmentRepository.findAll();
	}
	

	public Departments getDepartmentsByDepNo(String deptNo) throws DepartmentsNotFoundException {
		 Departments department = departmentRepository.findByDeptNo(deptNo);
		    if (department == null) {
		        throw new DepartmentsNotFoundException("The department with " + deptNo + " doesn't exist");
		    }
		    return department;
	}

	
	
	public List<Departments> getDepartmentsByDeptName(String deptName) throws DepartmentsNotFoundException {
	    

	    List<Departments> departments = departmentRepository.findByDeptName(deptName);

	    if (departments.isEmpty()) {
	        throw new DepartmentsNotFoundException("No departments found for deptName: " + deptName);
	    }

	    return departments;
	}

	
	
	public Departments addDepartment(Departments departments) {
		return departmentRepository.save(departments);
	}
	
	
	public Departments updateByDeptNo(Departments departments)throws DepartmentsNotFoundException {
        Departments updateDepartments=departmentRepository.save(departments);
        if(updateDepartments==null) {
        	throw new DepartmentsNotFoundException("No Departments are found for the given criteria");
        }
		return updateDepartments;
		
	}
	

	public Departments updateByDeptName(Departments departments) throws DepartmentsNotFoundException {
        Departments updateDepartments=departmentRepository.save(departments);
        if(updateDepartments==null) {
        	throw new DepartmentsNotFoundException("No Departments are found for the given criteria");
        }
		return updateDepartments;
	}
	
	
	@Transactional
	public void deleteByDeptNo(String deptNo) {
	

	    // Retrieve the department by its deptNo
	    Departments department = departmentRepository.findByDeptNo(deptNo);

	    // Check if the department exists
	    if (department != null) {
	        // Delete the department
	        departmentRepository.delete(department);
	    }
	}

	
	@Transactional
	public void deleteByDeptName(String deptName)throws DepartmentsNotFoundException {
		String deleteCount=departmentRepository.deleteByDeptName(deptName);
		if(deleteCount==null) {
			throw new DepartmentsNotFoundException("No department found for the given criteria");
		}
	}
	
	public void addDepartment(@Valid DepartmentDTO departmentDTO) {
	    departmentRepository.save(departmentDTO);
	}




	



}
