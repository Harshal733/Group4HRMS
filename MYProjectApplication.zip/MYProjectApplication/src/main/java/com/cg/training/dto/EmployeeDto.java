package com.cg.training.dto;

import java.time.LocalDate;
import java.util.Collection;

import org.springframework.stereotype.Component;

import com.cg.training.entities.Gender;

@Component
public class EmployeeDto {
    private int empNo;
    private LocalDate birthDate;
    private String firstName;
    private String lastName;
    private Gender gender;
    private LocalDate hireDate;

    


	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public LocalDate getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public LocalDate getHireDate() {
		return hireDate;
	}
	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
		
		
	}
	
	
	public EmployeeDto(int empNo, LocalDate birthDate, String firstName, String lastName, Gender gender,
			LocalDate hireDate) {
		super();
		this.empNo = empNo;
		this.birthDate = birthDate;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.hireDate = hireDate;
	}
	public EmployeeDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmployeeDto(int empNo2, String firstName2, String lastName2, LocalDate hireDate2) {
		// TODO Auto-generated constructor stub
	}
	public Collection<EmployeeDto> getEmployeesJoinedAfterYear(int year) {
		// TODO Auto-generated method stub
		return null;
	}
	public int countEmployeesJoinedLast10Years(int noOfYears) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
