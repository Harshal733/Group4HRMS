package com.cg.training.services;

import java.util.Collection;
import java.util.List;

import com.cg.training.dto.AssignDepartmentDto;
import com.cg.training.dto.DepartmentEmployeeDto;
import com.cg.training.dto.EmployeeDto;
import com.cg.training.dto.TitlesDto;
import com.cg.training.entities.Employee;



public interface AdminHrmsConsumerService {
	
	
	
    int countEmployeesJoinedLast10Years(int noOfYears);

	void assignDepartment(AssignDepartmentDto assignDepartmentDto);

	void addEmployee(EmployeeDto employeeDto);

	Collection<EmployeeDto> getEmployeesJoinedinLast10Years(int noOfYears);

    


	
	
   
	

}
