package com.cg.training.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class AssignDepartmentDto {
	 @NotNull
	    private Integer employeeId;
	    
	    @NotNull
	    @NotBlank(message = "deptNo is not correct or should not be null")
	    private String departmentId;
	    
	    @NotNull
	    @FutureOrPresent
	    private LocalDate fromDate;
	    
	    @NotNull
	    @Future
	    private LocalDate endDate;

		public Integer getEmployeeId() {
			return employeeId;
		}

		public void setEmployeeId(@NotNull Integer employeeId) {
			this.employeeId = employeeId;
		}

		public String getDepartmentId() {
			return departmentId;
		}

		public void setDepartmentId(@NotNull String departmentId) {
			this.departmentId = departmentId;
		}

		public LocalDate getFromDate() {
			return fromDate;
		}

		public void setFromDate(LocalDate fromDate) {
			this.fromDate = fromDate;
		}

		public LocalDate getEndDate() {
			return endDate;
		}

		public void setEndDate(LocalDate endDate) {
			this.endDate = endDate;
		}

		public AssignDepartmentDto(@NotNull @NotNull Integer employeeId, @NotNull @NotNull String departmentId,
				@NotNull @FutureOrPresent LocalDate fromDate, @NotNull @Future LocalDate endDate) {
			super();
			this.employeeId = employeeId;
			this.departmentId = departmentId;
			this.fromDate = fromDate;
			this.endDate = endDate;
		}

		public AssignDepartmentDto() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
	    

}
